#ifndef HELPERS_H
#define HELPERS_H
#include "Arduino.h"

int isTime(unsigned long lastTime, unsigned int timeBetweenReadings);

#endif